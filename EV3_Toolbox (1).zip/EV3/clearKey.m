function clearKey
    global key
    key = 0;
end