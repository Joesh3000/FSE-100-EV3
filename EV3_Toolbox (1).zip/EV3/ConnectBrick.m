function brick = ConnectBrick(brickName)
    brick = Brick('ioType','instrbt','btDevice',brickName,'btChannel',1);
end